import java.util.Date;

public class Employee extends Person {

	public Employee(String string, Date date) {
		super(string, date);
		// TODO Auto-generated constructor stub
	}

	public Employee(String string, Date date, String string2) {
		super(string, date, string2);
		// TODO Auto-generated constructor stub
	}
}
